import React from 'react';
import DataTable from './Components/DataTable';

const App = () => {


  return (
    <div>
<DataTable />
    </div>
  );
};

export default App;