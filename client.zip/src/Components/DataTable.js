import React, { useState, useEffect } from 'react';
import axios from "axios"
import "./DataTable.css"
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowUp, faArrowDown } from '@fortawesome/free-solid-svg-icons';
import 'bootstrap/dist/css/bootstrap.min.css';

const DataTable = () => {
  const [data, setData] = useState([])
  const [editableData, setEditableData] = useState(data);
  const [editingIndex, setEditingIndex] = useState(-1);
  const [previousData, setPreviousData] = useState(0);
  const [sortOrder, setSortOrder] = useState('asc'); // Initial sorting order

  const [selectedOption, setSelectedOption] = useState(); // Initial selected option

  const handleOptionChange = async (e) => {
    // setSelectedOption(e.target.value);
    try {
      console.log('selected option ->', e.target.value)
      const edit = await axios.get(`http://localhost:5000/getDataByCategory/${e.target.value}`)
      console.log("category:", edit.data)
      setData(edit.data);
    } catch (error) {
      console.log('error of handle option change ->', error)
    }
  };

  useEffect(() => {
    handleOptionChange()
  }, []);



  useEffect(() => {
    setEditableData(data);

  }, [data]);

  const handleEditClick = (index, prev) => {
    const data123 = parseFloat(prev)
    setPreviousData(data123)
    setEditingIndex(index);
  };

  const handleResetClick = async (index, id, price) => {
    setEditingIndex(-1);

    try {
      const edit = await axios.put(`http://localhost:5000/updateData/${id}`, { price: previousData })
      getAllData();

    } catch (error) {
      console.log(error)
    }
    // setEditableData(data);
  };

  const getAllData = async () => {
    return axios
      .get(`http://localhost:5000/getData`)
      .then((response) => {
        console.log("getdata", response.data.result);
        setData(response.data.result);
      })
      .catch((err) => console.log(err));
  };

  useEffect(() => {
    getAllData()


  }, []);

  const handleSaveClick = async (index, id, price) => {

    try {
      const edit = await axios.put(`http://localhost:5000/updateData/${id}`, { price })
      getAllData();
      // setPreviousData(prev)

      console.log("edit:", edit.data)
    } catch (error) {
      console.log(error)
    }

    setEditingIndex(-1);
  };


  // const handleSortClick = () => {
  //   // Toggle the sort order when the button is clicked
  //   setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
  // };

  const handleSortClick = () => {
    // Toggle the sorting order when the "Sort" button is clicked
    setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    // Sort the data based on the selected sorting order and the "price" field
    const sortedData = [...editableData].sort((a, b) => {
      if (sortOrder === 'asc') {
        return a.price - b.price;
      } else {
        return b.price - a.price;
      }
    });
    setEditableData(sortedData);
  };

  const handleFieldChange = (index, field, value) => {
    const newData = [...editableData];
    newData[index][field] = value;
    setEditableData(newData);
  };

  return (
    <div className='body'>

      <table >
        <thead>
          <tr>
            <th>ID</th>
            <th style={{ width: "90px" }}>Name</th>
            <th>Image</th>
            <th style={{ width: "200px" }}>
              <label htmlFor="dropdown">Category</label>
              <select id="dropdown" onChange={handleOptionChange} style={{ width: "80px", marginLeft: "5px" }}>
                <option value="mains">mains</option>
                <option value="appetizer">appetizer</option>
                <option value="dessert">dessert</option>
                <option value="clone">clone</option>
                <option value="weird">weird</option>

              </select>
            </th>
            <th>Label</th>
            <th style={{ width: '140px' }}>
              Price{' '}
              <button onClick={handleSortClick}>
                {' '}
                {sortOrder === 'asc' ? (
                 <FontAwesomeIcon icon={faArrowUp} /> // Up arrow icon for ascending
                ) : (
                  <FontAwesomeIcon icon={faArrowDown} /> // Down arrow icon for descending
                )}
              </button>
            </th>
            <th>Description</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {editableData.map((row, index) => (
            <tr key={row.id}>
              <td>{row.id}</td>
              <td>
                {row.name}
              </td>
              <td><img src={row.image} alt="Image" style={{ width: "100px", height: "100px" }} /></td>
              <td>

                {row.category}

              </td>
              <td>

                {row.label}
              </td>
              <td>
                {editingIndex === index ? (
                  <input
                    type="number"
                    value={row.price}
                    onChange={(e) => {
                      handleFieldChange(index, 'price', parseFloat(e.target.value))
                    }
                    }
                  />
                ) : (
                  row.price
                )}
              </td>
              <td>
                {row.description}
              </td>
              <td>
                {editingIndex === index ? (
                  <>
                    <button onClick={() => handleSaveClick(index, row.id, row.price)}>Save</button>
                  </>
                ) : (<div style={{ width: "200px" }}>
                  <button onClick={() => handleEditClick(index, data[row.id].price)}>Edit</button>
                  <button onClick={() => handleResetClick(index, row.id, data[row.id].price)}>Reset</button>
                </div>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default DataTable;
