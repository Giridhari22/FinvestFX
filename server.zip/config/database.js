const mongoose = require("mongoose")
MONGO_URI = "mongodb+srv://testingsdd123:7gzT3hWagodO7imY@cluster0.joyjwpl.mongodb.net/mernAssignment?retryWrites=true&w=majority"
// const MONGO_URI = process.env.MONGO_URI
// console.log(process.env.MONGO_URI)

const database = async()=> {
     await mongoose.connect(MONGO_URI,

        { useNewUrlParser : true ,useUnifiedTopology:true})
        .then(res=>{
            console.log('Database connected')
        })
        .catch((err)=>{
            console.error(`Error connecting to the Database ${err}`)
        })
    }

    module.exports = database