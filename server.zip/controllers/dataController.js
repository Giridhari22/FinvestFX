const { dataSet } = require("../config/data");
const Data = require("../models/dataSchema");


exports.createData = async(req,res) =>{
    try {
        const result = await Data.insertMany(dataSet);
        res.status(200).json({ msg: "Data Saved Successfully....!", result });       
    } catch (error) {
        console.log(error)
    }
}


exports.getData = async(req,res)=>{
    try {
        const result = await Data.find()
        if(result){
          return  res.status(200).json({msg:"here is your data" , result})
        }
        else {
            return  res.status(404).json({msg:" data not found" })

        }
    } catch (error) {
        console.log(error)
    }
}

exports.updateData = async (req, res) => {
    const { id } = req.params;
    const { price } = req.body;
    console.log('price', price)
  
    try {
      // Find the document by ID and update the price
      const updatedData = await Data.findOneAndUpdate(
        { id: id },
        { price: price },
        { new: true } // To get the updated document
      );
  
      if (!updatedData) {
        return res.status(404).json({ success: false, message: 'Data not found' });
      }
  
      return res.status(200).json({
        success: true,
        message: 'Data updated successfully',
        data: updatedData,
      });
    } catch (error) {
      return res.status(500).json({ success: false, error: error.message });
    }
  }

  exports.resetData = async (req, res) => {
    const { id } = req.params;
    const { price } = req.body;
    console.log('reset price', price)
  
    try {
      // Find the document by ID and update the price
      const updatedData = await Data.findOneAndUpdate(
        { id: id },
        { price: price },
        { new: true } // To get the updated document
      );
  
      if (!updatedData) {
        return res.status(404).json({ success: false, message: 'Data not found' });
      }
  
      return res.status(200).json({
        success: true,
        message: 'Data updated successfully',
        data: updatedData,
      });
    } catch (error) {
      return res.status(500).json({ success: false, error: error.message });
    }
  }


exports.getDataByCategory = async (req, res) => {
    const category = req.params.category;
  
    try {
      // Find data with the specified category
      const data = await Data.find({ category: category });
  
      if (data.length === 0) {
        return res.status(404).json({ message: "No data found for this category" });
      }
  
      res.status(200).json(data);
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: "Server error" });
    }
  };