const Router =  require("express")
const router = Router();
const func = require("../controllers/dataController.js")


// Question route api
router.get('/getData',func.getData )
router.post('/createData',func.createData)
// router.delete('/dropQuestions', question.dropQuestions)
router.put('/updateData/:id' , func.updateData)
router.put('/resetData/:id' , func.resetData)
router.get('/getDataByCategory/:category',func.getDataByCategory)


module.exports =router;