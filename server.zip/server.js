const express = require("express");
const app = express()
const path = require("path")
const cors = require('cors');
const bodyParser = require('body-parser')
const PORT = 5000; 
const database = require("./config/database.js")
const dataRoute = require("./routes/dataRouter.js")

app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.json())
app.use("/",dataRoute)

database()


app.listen(PORT , (req,res)=>{
    console.log(`server is running on port ${PORT}`)
})